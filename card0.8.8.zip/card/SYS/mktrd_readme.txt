MKTRD v0.1
by LaesQ / Papaya Dezign - 15/04/2014

Description
-----------

Creates a blank double sided, 80 track TRD disk image.

Usage
-----

mktrd trdname.trd [disklabel]

trdname.trd is the name of the image file to create.
disklabel is optional. It will be used as the disk label used by TR-DOS.

Please use with esxdos 0.8.x.

Contact
-------

laesq@esxdos.org

